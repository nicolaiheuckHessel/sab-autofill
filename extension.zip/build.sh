zip -r extension.zip .
