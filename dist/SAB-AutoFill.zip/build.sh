zip -r dist/SAB-AutoFill.zip .
