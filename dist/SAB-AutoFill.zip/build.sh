#!/bin/bash
zip -r dist/SAB-AutoFill.zip *