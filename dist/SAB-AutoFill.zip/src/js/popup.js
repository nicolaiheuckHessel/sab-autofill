// alert(1);
document.getElementById("profile-edit-form").remove();